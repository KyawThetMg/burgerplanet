<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
  <meta charset="utf-8" />
  <meta http-equiv="X-UA-Compatible" content="IE=edge" />
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
  <meta name="keywords" content="" />
  <meta name="description" content="" />
  <meta name="author" content="" />
  <title>BurgerPlanet</title>
  <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.1.3/assets/owl.carousel.min.css" />
  <link rel="stylesheet" type="text/css" href="css/bootstrap.css" />
  <link href="https://fonts.googleapis.com/css?family=Baloo+Chettan|Poppins:400,600,700&display=swap" rel="stylesheet">
  <link href="css/style.css" rel="stylesheet" />
  <link href="css/responsive.css" rel="stylesheet" />
</head>
<body>
<div class="hero_area">
<nav class="navbar navbar-expand-md fixed-right navbar-light bg-light">
      <a class="navbar-brand" href="index.php" class="pt-5 mt-5">Burger Planet</a>
      <button class="navbar-toggler p-0 border-0" type="button" data-toggle="offcanvas">
        <span class="navbar-toggler-icon"></span>
      </button>

      <div class="navbar-collapse offcanvas-collapse" id="navbarsExampleDefault">
        <ul class="navbar-nav ml-auto">
          <li class="nav-item">
            <a class="nav-link mr-5" href="product.php">PRODUCTS</a>
          </li>
          <li class="nav-item">
            <a class="nav-link mr-5" href="contact.php">CONTACT</a>
          </li>
          <!-- <li class="nav-item ">
            <a class="nav-link btn btn-outline-success" href="register.php">SIGN UP</a>
          </li> -->
          <li class="nav-item ">
            <a class="nav-link btn btn-outline-success" href="register.php">SIGN UP</a>
          </li>
        </ul>
      </div>
    </nav>
    <div id="tooplate_main" >
<?php
error_reporting(1);
include("connection.php");
if($_POST['sub'])
{ 
$name=$_POST['t1'];
$email=$_POST['t2'];
$phone=$_POST['t3'];
$mesg=$_POST['t4'];
if(mysql_query("insert into content(name,email,phone,mesg) values('$name','$email','$phone','$mesg')"))
{$er="<font color='red' size='+1'> Message sent successfully</font>"; }
}

?>
    <img src="images/welcome.gif" align="left">
    <div id="contact_form" class="col_2 mt-5 pt-5" style="width:500px; margin-left:auto; text-align: center; font-family: monospace; font-weight: bold;">
    <h3>Send a message</h3>
    <form method="post" name="contact" action="#">
    <div class="col_4">
        <label for="phone">Name:</label>
        <input type="text" id="t1" name="t1" class="required input_field" />
    </div>
    <div class="col_4 no_margin_right">
        <label for="email">Email:</label>
        <input type="email" id="t2" name="t2" class="validate-email required input_field" />
    </div>
    <div class="clear h10"></div>
     <div class="col_4 no_margin_right">
        <label for="phone">Phone:</label>
        <input type="text" id="t3" name="t3" class="required input_field" />
    </div>
    <div class="clear"></div>
        <label for="text">Message:</label> <textarea id="t4" name="t4" rows="0" cols="0" class="required"></textarea>
        <input type="submit" name="sub"  id="sub" value="Send" class="submit_button" />
    </form>
	<h2><?php echo $er;?></h2>
    </div>
    </div>
    <div style="display:none;" class="nav_up" id="nav_up"></div>
</div>
<script src="js/scroll-startstop.events.jquery.js" type="text/javascript"></script>
<script type="text/javascript">
	$(function() {
		var $elem = $('#content');
		
		$('#nav_up').fadeIn('slow');
		
		$(window).bind('scrollstart', function(){
			$('#nav_up,#nav_down').stop().animate({'opacity':'0.2'});
		});
		$(window).bind('scrollstop', function(){
			$('#nav_up,#nav_down').stop().animate({'opacity':'1'});
		});
		
		$('#nav_up').click(
			function (e) {
				$('html, body').animate({scrollTop: '0px'}, 800);
			}
		);
	});
</script>

</body>
</html>