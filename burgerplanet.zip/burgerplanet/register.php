<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
  <meta charset="utf-8" />
  <meta http-equiv="X-UA-Compatible" content="IE=edge" />
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
  <meta name="keywords" content="" />
  <meta name="description" content="" />
  <meta name="author" content="" />
  <title>BurgerPlanet</title>
  <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.1.3/assets/owl.carousel.min.css" />
  <link rel="stylesheet" type="text/css" href="css/bootstrap.css" />
  <link href="https://fonts.googleapis.com/css?family=Baloo+Chettan|Poppins:400,600,700&display=swap" rel="stylesheet">
  <link href="css/style.css" rel="stylesheet" />
  <link href="css/responsive.css" rel="stylesheet" />
  <style type="text/css">

  	form label{
  		color:black;
  	}
  </style>
</head>
<body style="background-color:#85C1E9 ;">
    <div class="pt-5">
    <div style="width:200px;margin:auto; color:black;" class="pt-5">
            <h3 >Register form</h3>
            <?php
error_reporting(1);
include("connection.php");
if($_POST['sub'])
{ 
$name=$_POST['t1'];
$email=$_POST['t2'];
$password=$_POST['t3'];
$phone=$_POST['t4'];
$city=$_POST['t5'];
$town=$_POST['t6'];
if(mysql_query("insert into register(name,email,password,phone,city,township) values('$name','$email','$password','$phone','$city','$town')"))
{
//echo "<script>location.href='reg_success.php?email=$email'</script>"; 
header("location:reg_success.php?name=$name & email=$email");}
else {$error= "user already exists";}}

?>
            <form  method="post">
                <label>Name </label>
                <input type="text" name="t1" id="t1" class="input_field" placeholder="John Wick" required />
                <label>Email</label>
                <input type="email" name="t2" id="t2" class="input_field" placeholder="example@gmail.com" required />
				 <label>Password</label>
                <input type="password" name="t3" id="t3" class="input_field" placeholder="password" required />
				 <label>Phone </label>
                <input type="text" name="t4" id="t4" class="input_field" placeholder="09*********" required />
				 <label>City </label>
                <input type="text" name="t5" id="t5" class="input_field" placeholder="ygn" required />
				 <label>Country </label>
                <input type="text" name="t6" id="t6" class="input_field" placeholder="mm"  required />
                <input type="submit" name="sub" id="sub" value="Register" class="submit_button mt-3 btn btn-primary" />
				<label><?php echo "<font color='red'>$error</font>";?>
                </label>
            </form> </div></div>
<script src="js/scroll-startstop.events.jquery.js" type="text/javascript"></script>
<script type="text/javascript">
	$(function() {
		var $elem = $('#content');
		
		$('#nav_up').fadeIn('slow');
		
		$(window).bind('scrollstart', function(){
			$('#nav_up,#nav_down').stop().animate({'opacity':'0.2'});
		});
		$(window).bind('scrollstop', function(){
			$('#nav_up,#nav_down').stop().animate({'opacity':'1'});
		});
		
		$('#nav_up').click(
			function (e) {
				$('html, body').animate({scrollTop: '0px'}, 800);
			}
		);
	});
</script>

</body>
</html>