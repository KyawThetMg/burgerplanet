<?php
session_start();
error_reporting(1);
$i=$_REQUEST['img'];
include("connection.php");
if(isset($_POST['log'])){ 
    if($_POST['id']=="" || $_POST['pwd']==""){ 
        $err="fill your id and password first";
    }else{
        $d=mysql_query("select * from register where email='{$_POST['id']}' ");
        $row=mysql_fetch_object($d);
        $fid=$row->email;
        $fpass=$row->password;

        if($fid==$_POST['id'] && $fpass==$_POST['pwd']){
            $_SESSION['sid']=$_POST['id'];
        //echo"<script>location:href='order.php?img=$i'</script>";
            header("location:order.php?img=$i"); 
        }else{
            $err=" your password is not"; 
        }
    }
}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
  <meta charset="utf-8" />
  <meta http-equiv="X-UA-Compatible" content="IE=edge" />
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
  <meta name="keywords" content="" />
  <meta name="description" content="" />
  <meta name="author" content="" />
  <title>BurgerPlanet</title>
  <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.1.3/assets/owl.carousel.min.css" />
  <link rel="stylesheet" type="text/css" href="css/bootstrap.css" />
  <link href="https://fonts.googleapis.com/css?family=Baloo+Chettan|Poppins:400,600,700&display=swap" rel="stylesheet">
  <link href="css/style.css" rel="stylesheet" />
  <link href="css/responsive.css" rel="stylesheet" />
</head>
<body style="background-color:#85C1E9;color:black;">
<div id="tooplate_main" class="pt-5">
<h2 class="submit_button btn btn-light ml-5" ><a href="index.php">Back</a></h2>
<div id="contact_form" class="col_2 pt-5" style="width:250px;margin:auto;">
    <h1>Login</h1>
    <form method="post" name="contact" action="#">
    <div class="col_4 no_margin_right">
    <label for="email"> Email:</label>
    <input type="email" id="id" name="id" class="required input_field" />
    </div>
    <div class="col_4 no_margin_right">
    <label for="password">Password:</label>
    <input type="password" id="pwd" name="pwd" class="validate-email required input_field" />
    </div>
    <p>Don't have an account? Register <a href="register.php">here</a>.</p>
    <div class="clear"></div>
    <input type="submit" name="log"  value="Log in" class="submit_button btn btn-primary" />
    </form>
    <h2><?php echo $err;?></h2>
</div>    	
<script src="js/scroll-startstop.events.jquery.js" type="text/javascript"></script>
<script type="text/javascript">
	$(function() {
		var $elem = $('#content');
		
		$('#nav_up').fadeIn('slow');
		
		$(window).bind('scrollstart', function(){
			$('#nav_up,#nav_down').stop().animate({'opacity':'0.2'});
		});
		$(window).bind('scrollstop', function(){
			$('#nav_up,#nav_down').stop().animate({'opacity':'1'});
		});
		
		$('#nav_up').click(
			function (e) {
				$('html, body').animate({scrollTop: '0px'}, 800);
			}
		);
	});
</script>

</body>
</html>