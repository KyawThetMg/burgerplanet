<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
  <meta charset="utf-8" />
  <meta http-equiv="X-UA-Compatible" content="IE=edge" />
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
  <meta name="keywords" content="" />
  <meta name="description" content="" />
  <meta name="author" content="" />
  <title>BurgerPlanet</title>
  <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.1.3/assets/owl.carousel.min.css" />
  <link rel="stylesheet" type="text/css" href="css/bootstrap.css" />
  <link href="https://fonts.googleapis.com/css?family=Baloo+Chettan|Poppins:400,600,700&display=swap" rel="stylesheet">
  <link href="css/style.css" rel="stylesheet" />
  <link href="css/responsive.css" rel="stylesheet" />
  <style>
        h3{
            color:rgb(51, 211, 88);
        }
    .div1{
      padding:5px;
      height:480px;
      color:white;
      background: #922724;
      width:100%;
    }
    main{
      margin-left:100px;
      padding:5px;
    }
    main div{
      width:600px;
    }
    .section{
        width:90%;
        margin:auto;
    }
    .section div{
    float:left;
      width:500px;
    }
    footer{
      width:100%;
      height:200px;
      color:white;
      background-color:dark;
      color:black;
    }
    footer a{
      text-decoration:none;
    }
    footer div{
      float:left;
      width:30%;
      margin-left:30px;
    }
    </style>
</head>
<body>

<div class="hero_area">

<header>
  <nav class="navbar navbar-expand-md fixed-right navbar-light bg-light">
      <a class="navbar-brand" href="#" class="pt-5 mt-5">Burger Planet</a>
      <button class="navbar-toggler p-0 border-0" type="button" data-toggle="offcanvas">
        <span class="navbar-toggler-icon"></span>
      </button>

      <div class="navbar-collapse offcanvas-collapse" id="navbarsExampleDefault">
        <ul class="navbar-nav ml-auto">
          <li class="nav-item">
            <a class="nav-link mr-5" href="product.php">PRODUCTS</a>
          </li>
          <li class="nav-item">
            <a class="nav-link mr-5" href="contact.php">CONTACT</a>
          </li>
          <!-- <li class="nav-item">
            <a class="nav-link btn btn-outline-primary mr-5" href="login.php">LOGIN</a>
          </li> -->
          <li class="nav-item ">
            <a class="nav-link btn btn-outline-success" href="register.php">SIGN UP</a>
          </li>
        </ul>
      </div>
    </nav>
  </header>
  /<script type="text/javascript">
    $(document).ready(function() {
  $(window).scroll(function() {
    if($(this).scrollTop() < $("#green").height()){
       $(".navbar").removeClass("bg-dark");
    }
    else{
       $(".navbar").addClass("bg-dark");
    }
  });
});
  </script> -->
    <div class="item_section layout_padding2">
  
    <div class="container">
      <div class="item_container">
        <a href="product.php">
        <div class="box">
          <div class="price">
            <h6>
              Best PRICE
            </h6>
          </div>
          <div class="img-box">
            <img src="burger_image/R.jpg" alt="">
          </div>
          <div class="name">
            <h5>
              Burger
            </h5>
          </div>
        </div></a>
        <a href="product.php">
        <div class="box">
          <div class="price">
            <h6>
              Best PRICE
            </h6>
          </div>
          <div class="img-box">
            <img src="burger_image/R.jpg" alt="">
          </div>
          <div class="name">
            <h5>
              Burger
            </h5>
          </div>
        </div></a>
        <a href="product.php">
        <div class="box">
          <div class="price">
            <h6>
              Best PRICE
            </h6>
          </div>
          <div class="img-box">
            <img src="burger_image/R.jpg" alt="">
          </div>
          <div class="name">
            <h5>
              Burger
            </h5>
          </div>
        </div></a>
        <a href="product.php">
        <div class="box">
          <div class="price">
            <h6>
              Best PRICE
            </h6>
          </div>
          <div class="img-box">
            <img src="burger_image/R.jpg" alt="">
          </div>
          <div class="name">
            <h5>
              Burger
            </h5>
          </div>
        </div></a>
          <a href="product.php">
        <div class="box">
          <div class="price">
            <h6>
              Best PRICE
            </h6>
          </div>
          <div class="img-box">
            <img src="burger_image/Q.png" alt="">
          </div>
          <div class="name">
            <h5 class="pl-5">
              Pizza
            </h5>
          </div>
        </div></a>
        <a href="product.php">
        <div class="box">
          <div class="price">
            <h6>
              Best PRICE
            </h6>
          </div>
          <div class="img-box">
            <img src="burger_image/S.jpg" alt="">
          </div>
          <div class="name">
            <h5>
              Coke
            </h5>
          </div>
        </div></a>
      </div>
    </div>
  </div>
</div> <!-- END of tooplate_footer_wrapper -->
 <div class="div1" class="mt-5">
<main>
  <div>
    <h3>Quotes That Inspired Us</h3>
    <p>Hopes and dreams were dashed that day. It should have been expected, 
    but it still came as a shock. The warning signs had been ignored in favor of
    the possibility, however remote, that it could actually happen.
    That possibility had grown from hope to an undeniable belief it must be destiny.
    That was until it wasn't and the hopes and dreams came crashing down.</p>
  </div>
  <section class="section">
    <div>
      <h3>Your Choice</h3>
      <p>All he wanted was a candy bar. It didn't seem like a difficult request to comprehend,
      but the clerk remained frozen and didn't seem to want to honor the request. 
      It might have had something to do with the gun pointed at his face.</p>
    </div>
    <div>
      <h3>Your Choice is My CHOICE</h3>
      <p>The coin hovered in the air, spinning over and over again. It reached its peak and began to descend.
      </p>
      <h3>Your Choice Matter Most</h3>
      <p>Both boys were pleading with it to land a certain way but the coin had already made up its mind on what it was going to do.</p>
    </div>
  </section>
</main>
</div>
<footer class="p-5">
  <div>
    <h3>Ask Us</h3>
    <p>Email:<a href="mailto:ktmkyawgyi@gmail.com" title="gmail">ktmkyawgyi@gmail.com</a></p>
  </div>
  <div>
    <h3>About Us</h3>
    <p><a href="#">BurgerPlanet</a></p>
  </div>
  <div> 
    <h3>More</h3>
    <p><a href="#">Planet</a></p>
  </div>
  
</footer>
<script src="js/scroll-startstop.events.jquery.js" type="text/javascript"></script>
<script type="text/javascript">
	$(function() {
		var $elem = $('#content');
		
		$('#nav_up').fadeIn('slow');
		
		$(window).bind('scrollstart', function(){
			$('#nav_up,#nav_down').stop().animate({'opacity':'0.2'});
		});
		$(window).bind('scrollstop', function(){
			$('#nav_up,#nav_down').stop().animate({'opacity':'1'});
		});
		
		$('#nav_up').click(
			function (e) {
				$('html, body').animate({scrollTop: '0px'}, 800);
			}
		);
	});
</script>

</body>
</html>